var cr_url = "crawler_json/"
var current_crawler = null;


String.prototype.replaceAll = function(search, replacement) {
	var target = this;
	return target.split(search).join(replacement);
};


function addDescription(report, crawler) {
		var reports = getByType("report", crawler['objects']);
		$('.description').html(reports[0].description.replaceAll("\r\n", "</br>"));
		$('.info').empty();
		$('.info').html(reports[0].source);
}


function getObjectFromCrawler(id_in, crawler) {
	return crawler.objects.find(function(obj) {
		if (id_in == obj.id) {
			return obj
		}
	});
}


jQuery(document).ready(function($) {

});


$('#crawler_button').on('click', function() {
	var cr_file = $(this).attr("cr_file");
	var crawler;
	loadCrawler(cr_url + cr_file, crawler);
});


$(document).on('click', '.btn-report', function(event) {
	var report_id = $(this).attr("report_id");
	highlightLink(report_id);
	var reports = getByType("report", current_crawler['objects']);
		for (report in reports) {
			if (reports[report].id == report_id) {
				$('.description').html(reports[report].description.replaceAll("\r\n", "</br>"));
				$('.info').empty();
				$('.info').html(reports[report].source);
			}
		}
});


function loadCrawler(cr_url, crawler) {
	$.getJSON(cr_url, function(data) {
		crawler = data;
		var reports = getByType("report", crawler['objects']);
		total_reports = 0;
		addDescription(null, crawler);
		addReportLinks(crawler);
		highlightLoadFirstLink(crawler);
		storeCurrentCrawler(crawler);
	})

}

function highlightLoadFirstLink(crawler) {
	var links = document.getElementsByClassName('timeline_btn');
	links[0].style.background = "#464646";
	var report_id = links[0].getAttribute("report_id");
}

function highlightLink(report_id) {
	var links = document.getElementsByClassName('timeline_btn');
	for (len = links.length, i = 0; i < len; ++i) {
		console.log(links[i]);
		if (links[i].getAttribute("report_id") == report_id) {
			links[i].style.background = "#464646";
		} else {
			links[i].style.background = null;
		}
	}
}

function storeCurrentCrawler(crawler) {
	current_crawler = crawler;
}

function getByType(type, myArray) {
	return myArray.filter(function(obj) {
		if (obj.type == type) {
			return obj
		}
	})
}

function addReportLinks(crawler) {
	var reports = getByType("report", crawler['objects']);
	$('.timeline').empty();
	crawler_markup = "";
	report_markup = "";

	var parsed_reports = [];
	for (var i = 0; i < reports.length; i++) {
			total_reports = total_reports + 1			
			parsed_reports.push({
				"id": reports[i].id,
				"name": reports[i].report_title,
			})	
	}
	
	for (i = 0; i < parsed_reports.length; i++) {

		rep = parsed_reports[i];

		title_text = rep.name;
		rep_width = rep.id.length;
		report_markup = '<div class="timeline_btn btn btn-report" ' + 'report_id="' + rep.id + '" style="width:90%;">' + title_text + '</div>'
		$('.timeline').append(report_markup);
	}
}


$(document).on('click', '.ap_button', function() {
	var ap_id = $(this).attr("ap_id");
	$('#' + ap_id).css({
		"display": "block"
	});

});


$(document).on('click', '.close', function() {
	$('.modal').css({
		"display": "none"
	});

});


$(document).on("click", function(event) {
	if ($(event.target).has(".modal-content").length) {
		$(".modal").hide();
	}
});