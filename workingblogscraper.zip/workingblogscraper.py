import requests
import re
import json
from datetime import datetime
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

BlogList = ["https://www.trustwave.com/Resources/SpiderLabs-Blog/","https://securelist.com/", "https://www.fireeye.com/blog/threat-research.html", \
            "https://www.arbornetworks.com/blog/asert/", "https://blog.fortinet.com/","https://blog.fox-it.com","https://labsblog.f-secure.com",\
            "https://heimdalsecurity.com/blog/security-alerts/","https://www.hotforsecurity.com/blog/category/e-threats/alerts",\
            "https://community.softwaregrp.com/t5/Security-Research/bg-p/off-by-on-software-security-blog", "https://blog.malwarebytes.com/",\
            "https://researchcenter.paloaltonetworks.com/", "https://www.proofpoint.com/us/threat-insight","https://www.secureworks.com/research",\
            "http://blog.trendmicro.com/trendlabs-security-intelligence/","https://www.welivesecurity.com/research/",\
            "https://www.welivesecurity.com/","https://www.zscaler.com/blogs"]
previouslyscraped = []
linklist = []

headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:45.0) Gecko/20100101 Firefox/45.0'}

archive = open("c:\\users\\[user]\\desktop\\done.txt").read().split("\n")
for dones in archive:
    if dones not in previouslyscraped:
        previouslyscraped.append(dones)

ioc_dedup = []


def firstscrape():
    for item in BlogList:
        print(item)
        
        try:
            a = str(requests.get(item, headers=headers, verify=False).content)
            #There's a famous Stack Overflow post on not using regex to scrape HTML.
            #There are reasons why that guy is right. There are also reasons why he
            #is wrong. One is that things like the BS4 library slow things down
            #considerably. Since we aren't really crawling more than a layer deep,
            #and since we are always looking for the same thing, there's no reason
            #to add a library that people have to install and that will inhibit
            #performance. Still, if you prefer a modular approach that would be
            #more accurate (but also takes time to build each module), it's included.
            
            links = re.findall('(?<=href=").*?(?=")', a)
            for each in links:
                print(each)
                if "http" in each:
                    
                    firstpart = str(re.search("http[s]{0,1}://[a-zA-Z0-9\.]*",each).group())
                    
                    firstpart = re.sub("https://","",firstpart)
                    firstpart = re.sub("http://","",firstpart)
                    
                    if firstpart in item:
                        if each not in previouslyscraped:
                            print(each)
                            secondscrape(each)
                            
                elif "http" not in each:
                    neweach = re.sub("^/","",each)
                    firsteach = str(re.search("http[s]{0,1}://.*?/",item).group())
                    assembledlink = (firsteach + neweach)
                    #print(assembledlink)
                    if assembledlink not in previouslyscraped:
                        linklist.append(assembledlink)
                        secondscrape(assembledlink)
        except:
            print("failed to request 1 " + item)
            

def secondscrape(nextpage):        
    iocreport = []
    #We need the first half of the URL for later so we can avoid
    #scraping the same content twice due to anchor tags. I toyed
    #with a few solutions here, and this one was the easiest to
    #use and understand. We'll be appending the scraped IOCs to
    #the base URL. One downside- if someone comments more IOCs
    #on a blog that doesn't auto-load the comments section, this
    #will lead to a double scrape. It *shouldn't* matter too much
    #because more often than not you'll have scraped the page
    #already.

    try:
        dedupfirsthalf = str(re.search("http[s]://{0,1}.*?/",nextpage).group())
    except:
        dedupfirsthalf = "Parse error"
    
    try:
        b = str(requests.get(nextpage, headers=headers, verify=False).content)
        q = re.sub("asdwf","",b)
        hashesMD5 = re.findall("(?<=\s)[0-9a-f]{32}(?=<)|(?<=>)[0-9a-f]{32}(?=<)|(?<=\s)[0-9a-f]{32}(?=\s)", b)
        hashesSHA1 = re.findall("(?<=\s)[0-9a-f]{40}(?=<)|(?<=>)[0-9a-f]{40}(?=<)|(?<=\s)[0-9a-f]{40}(?=\s)", b)
        hashesSHA256 = re.findall("(?<=\s)[0-9a-f]{64}(?=<)|(?<=>)[0-9a-f]{64}(?=<)|(?<=\s)[0-9a-f]{64}(?=\s)", b)
        ips = re.findall("(?<=\s)\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?=\s)|(?<=>)\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?=\s)|(?<=>)\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?=<)", b)
        
        if hashesMD5 or hashesSHA1 or hashesSHA256 or ips:

            #So, this line prevents the nonsense on blogs like Spiderlabs, where there are
            #fourteen different URLs for the same page. It's also a good primer on why it's
            #just practical to use RSS pages when you can, aside from just "it's rude not to."

            clunkyfix = (str(hashesMD5 + hashesSHA1 + hashesSHA256 + ips) + dedupfirsthalf)            
            if clunkyfix not in ioc_dedup:
                ioc_dedup.append(clunkyfix)
                iocreport.append(hashesMD5)
                iocreport.append(hashesSHA1)
                iocreport.append(hashesSHA256)
                iocreport.append(ips)

                        
                dd = re.findall("<p.*?>.*?</p>",q)
                #So, here we are cleaning up the HTML so we can render a nice block
                #of just regular old text in our front-end.
                
                newitem = ""

                for reassemble in dd:
                    reassemble = re.sub("<p>","",reassemble)
                    reassemble = re.sub("</p>","\r\n\r\n",reassemble)
                    reassemble = re.sub("<.*?>","",reassemble)
                    reassemble = re.sub("\r\n\r\n","<br><br>",reassemble)
                    reassemble = re.sub('"',"'",reassemble)
                    newitem = newitem + reassemble
                
                d = newitem 

                #Now we have our IOCs, we have our report. Let's add it to the JSON.
                #I'm using time.now and the URL as the report ID. Really, it could
                #be anything you want. I just wanted something that should be unique
                #and readable in case something breaks.

                reportpath = "C:\\Users\\[user]\\Downloads\\pan-unit42.github.io\\playbook_viewer\\crawler_json\\crawler.json"                
                storedreports = open(reportpath).read()
                dataconvert = json.loads(storedreports)
                objectiteration = dataconvert["objects"]
                newreport = {}
                
                #Again, if you think it's a crime to regex HTML, bite me.
                try:
                    firsttitle = str(re.search("(?<=<title>).*?(?=</title>)",b).group())
                    newreport['report_title'] = firsttitle[:42] + "..."
                except:
                    newreport['report_title'] = dedupfirsthalf
                    
                newreport['type'] = "report"
                newreport['source'] = nextpage
                newreport['id'] = str(datetime.now()) + dedupfirsthalf
                newreport['created'] = str(datetime.now())
                newreport['description'] = d

                objectiteration.insert(0, newreport)
                newjson = {}
                newjson['objects'] = objectiteration
                
                with open(reportpath, 'w') as outfile:
                    json.dump(newjson, outfile)
                
        
    except:
        raise

    cleanup(nextpage)

def cleanup(scraped):
    with open("c:\\users\\[user]\\desktop\\done.txt","a") as t:
        t.write(scraped + "\n")
        

#Originally, I called firstscrape to get all the links, then
#called secondscrape afterwards. My plan was to do multi-
#processing for each one. I abandoned it partway through when
#debugging something else. In this current form, you could
#probably add the firstscrape results to a list, add a for
#statement into second scrape and remove the variable. 
        
firstscrape()
